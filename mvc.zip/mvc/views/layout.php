<DOCTYPE html>
  <html>

  <head>
  </head>

  <body>
    <header>
      <a href='/mvc'>Accueil</a>
      <a href='?controller=person&action=index'>Rechercher</a>
    </header>

    <?php require_once('routes.php'); ?>

    <body>
      <html>
<p>Bonjour <?php echo $first_name . ' ' . $last_name; ?>!
<p>

<p>Bienvenue sur la page d'acceil!</p>
<div>
    <table>
        <tr>
            <td>ZERTy</td>
            <td>ZERTy</td>
            <td>ZERTy</td>
        </tr>
    </table>
</div>